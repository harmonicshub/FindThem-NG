import { CaseStatus } from "@/lib/types";

const styles: Record<CaseStatus, string> = {
  missing: "bg-alert-bg text-alert",
  found: "bg-found-bg text-found",
  pending: "bg-forest-mist text-forest-dark",
  rejected: "bg-red-100 text-red-700",
};

const labels: Record<CaseStatus, string> = {
  missing: "MISSING",
  found: "FOUND",
  pending: "PENDING REVIEW",
  rejected: "REJECTED",
};

export default function StatusBadge({ status }: { status: CaseStatus }) {
  return (
    <span
      className={`inline-block rounded px-2 py-0.5 font-display text-[11px] font-extrabold tracking-widest ${styles[status]}`}
    >
      {labels[status]}
    </span>
  );
}
