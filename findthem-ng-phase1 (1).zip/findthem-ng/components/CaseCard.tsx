import Link from "next/link";
import { MissingCase } from "@/lib/types";
import { formatDate, initials } from "@/lib/format";
import StatusBadge from "./StatusBadge";

export default function CaseCard({ c }: { c: MissingCase }) {
  return (
    <Link
      href={`/cases/${c.id}`}
      className="group overflow-hidden rounded-xl border border-forest-mist bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative h-52 bg-forest-dark">
        {c.photoUrl ? (
          // Plain <img> keeps the bundle light and works with runtime uploads
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={c.photoUrl}
            alt={`Photo of ${c.fullName}`}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="grid h-full w-full place-items-center font-display text-5xl font-black text-white/30">
            {initials(c.fullName)}
          </div>
        )}
        <div className="absolute left-0 top-3 flex items-center gap-2">
          <StatusBadge status={c.status} />
          <span className="rounded-r bg-black/50 px-2 py-0.5 text-[11px] font-semibold text-white">
            {c.caseNumber}
          </span>
        </div>
      </div>
      <div className="space-y-1 p-4">
        <h3 className="font-display text-lg font-extrabold leading-tight text-forest-dark group-hover:text-forest">
          {c.fullName}, {c.age}
        </h3>
        <p className="text-sm text-ink/80">
          Last seen: {c.lastSeenLocation}, {c.state}
        </p>
        <p className="text-xs text-ink/50">{formatDate(c.lastSeenDate)}</p>
      </div>
    </Link>
  );
}
