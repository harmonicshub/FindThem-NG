// Edge-safe helpers (Web Crypto only) — used by both middleware and routes.
export const ADMIN_COOKIE = "ft_admin";

export function adminPassword(): string {
  return process.env.ADMIN_PASSWORD || "findthem-admin";
}

export async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
