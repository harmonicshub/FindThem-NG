import { promises as fs } from "fs";
import path from "path";
import { MissingCase } from "./types";

// Phase 1 storage: a JSON file on disk. All reads/writes go through this
// module, so moving to Supabase/Postgres in Phase 2 means changing this
// one file only.
const DB_PATH = path.join(process.cwd(), "data", "cases.json");

export async function readCases(): Promise<MissingCase[]> {
  try {
    const raw = await fs.readFile(DB_PATH, "utf8");
    return JSON.parse(raw) as MissingCase[];
  } catch {
    return [];
  }
}

export async function writeCases(cases: MissingCase[]): Promise<void> {
  await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
  await fs.writeFile(DB_PATH, JSON.stringify(cases, null, 2), "utf8");
}

export function nextCaseNumber(cases: MissingCase[]): string {
  const year = new Date().getFullYear();
  return `FT-${year}-${String(cases.length + 1).padStart(4, "0")}`;
}

export function publicCases(cases: MissingCase[]): MissingCase[] {
  return cases
    .filter((c) => c.status === "missing" || c.status === "found")
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}
