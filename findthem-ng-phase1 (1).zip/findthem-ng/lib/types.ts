export type CaseStatus = "pending" | "missing" | "found" | "rejected";

export interface MissingCase {
  id: string;
  caseNumber: string; // e.g. FT-2026-0001
  fullName: string;
  age: number;
  gender: "Male" | "Female";
  state: string;
  lga: string;
  lastSeenLocation: string;
  lastSeenDate: string; // ISO date (yyyy-mm-dd)
  description: string;
  photoUrl: string | null;
  contactPhone: string; // shown publicly on the case page
  reporterName: string;
  reporterPhone: string; // private — admin only
  relationship: string;
  status: CaseStatus;
  createdAt: string;
  updatedAt: string;
}
