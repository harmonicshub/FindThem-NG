import Link from "next/link";
import { readCases, publicCases } from "@/lib/db";
import CaseCard from "@/components/CaseCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const all = await readCases();
  const cases = publicCases(all);
  const active = cases.filter((c) => c.status === "missing").length;
  const found = cases.filter((c) => c.status === "found").length;
  const recent = cases.slice(0, 6);

  return (
    <>
      <section className="border-b border-forest-mist bg-forest-dark text-white">
        <div className="mx-auto max-w-5xl px-4 py-14 sm:py-20">
          <p className="mb-3 font-display text-xs font-bold tracking-[0.3em] text-white/60">
            NIGERIA&apos;S COMMUNITY MISSING-PERSONS BOARD
          </p>
          <h1 className="max-w-2xl font-display text-4xl font-black leading-tight sm:text-5xl">
            Every face on this board is someone&apos;s person.
          </h1>
          <p className="mt-4 max-w-xl text-white/80">
            Search active cases, share them, and report a missing person in minutes —
            built to load fast on any network, on any phone.
          </p>

          <form action="/cases" method="GET" className="mt-8 flex max-w-xl gap-2">
            <input
              type="search"
              name="q"
              placeholder="Search by name or location…"
              className="w-full rounded-lg border-0 px-4 py-3 text-ink outline-none ring-2 ring-transparent focus:ring-white/60"
            />
            <button
              type="submit"
              className="rounded-lg bg-white px-5 py-3 font-display text-sm font-extrabold text-forest-dark hover:bg-forest-mist"
            >
              Search
            </button>
          </form>

          <div className="mt-10 flex gap-8">
            <div>
              <p className="font-display text-3xl font-black">{active}</p>
              <p className="text-xs uppercase tracking-widest text-white/60">Active cases</p>
            </div>
            <div>
              <p className="font-display text-3xl font-black text-green-300">{found}</p>
              <p className="text-xs uppercase tracking-widest text-white/60">Found</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-2xl font-extrabold text-forest-dark">Recent cases</h2>
          <Link href="/cases" className="text-sm font-semibold text-forest hover:underline">
            View all →
          </Link>
        </div>
        {recent.length === 0 ? (
          <div className="rounded-xl border border-dashed border-forest-mist bg-white p-10 text-center">
            <p className="font-display text-lg font-bold text-forest-dark">No cases yet</p>
            <p className="mt-1 text-sm text-ink/60">
              Approved reports will appear here.{" "}
              <Link href="/report" className="font-semibold text-forest underline">
                Report a case
              </Link>{" "}
              to get started.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {recent.map((c) => (
              <CaseCard key={c.id} c={c} />
            ))}
          </div>
        )}
      </section>

      <section className="border-t border-forest-mist bg-white">
        <div className="mx-auto grid max-w-5xl gap-6 px-4 py-10 sm:grid-cols-3">
          {[
            ["Report", "Fill one form with the person's details and photo. It takes about 3 minutes."],
            ["Review", "Our team checks every report before it goes public, to keep the board trustworthy."],
            ["Share", "Every case page has a one-tap WhatsApp share — the fastest way news travels in Nigeria."],
          ].map(([title, text]) => (
            <div key={title}>
              <h3 className="font-display text-lg font-extrabold text-forest-dark">{title}</h3>
              <p className="mt-1 text-sm text-ink/70">{text}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
