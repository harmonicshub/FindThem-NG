import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "FindThem NG — Missing Persons Nigeria",
  description:
    "Report and search missing-person cases across Nigeria. Fast, mobile-first, community-driven.",
};

export const viewport: Viewport = {
  themeColor: "#0C3B32",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800;900&family=Inter:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="flex min-h-screen flex-col font-sans">
        <header className="sticky top-0 z-40 border-b border-forest-mist bg-paper/95 backdrop-blur">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
            <Link href="/" className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-forest-dark font-display text-sm font-black text-white">
                F
              </span>
              <span className="font-display text-lg font-extrabold tracking-tight text-forest-dark">
                FindThem <span className="text-forest">NG</span>
              </span>
            </Link>
            <nav className="flex items-center gap-4 text-sm font-medium">
              <Link href="/cases" className="text-ink/70 hover:text-forest-dark">
                Cases
              </Link>
              <Link
                href="/report"
                className="rounded-full bg-forest-dark px-4 py-2 text-white hover:bg-forest"
              >
                Report a case
              </Link>
            </nav>
          </div>
        </header>

        <main className="flex-1">{children}</main>

        <footer className="border-t border-forest-mist bg-forest-dark text-white">
          <div className="mx-auto flex max-w-5xl flex-col gap-2 px-4 py-6 text-sm sm:flex-row sm:items-center sm:justify-between">
            <p className="font-display font-bold">FindThem NG</p>
            <p className="text-white/70">
              If someone is in immediate danger, call the Police on <strong>112</strong> first.
            </p>
            <Link href="/admin" className="text-white/50 hover:text-white">
              Admin
            </Link>
          </div>
        </footer>
      </body>
    </html>
  );
}
