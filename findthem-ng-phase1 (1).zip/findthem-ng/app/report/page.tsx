"use client";

import { useState } from "react";
import Link from "next/link";
import { NIGERIAN_STATES } from "@/lib/states";

export default function ReportPage() {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ caseNumber: string } | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const form = new FormData(e.currentTarget);
      const res = await fetch("/api/cases", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong. Please try again.");
      setDone({ caseNumber: data.caseNumber });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-forest-mist bg-white p-8 shadow-sm">
          <p className="font-display text-5xl">✅</p>
          <h1 className="mt-3 font-display text-2xl font-black text-forest-dark">
            Report received
          </h1>
          <p className="mt-2 text-sm text-ink/70">
            Your case number is{" "}
            <span className="font-display font-extrabold text-forest">{done.caseNumber}</span>.
            Keep it for reference. Our team reviews every report before it goes public —
            usually within a few hours.
          </p>
          <Link
            href="/cases"
            className="mt-6 inline-block rounded-lg bg-forest-dark px-5 py-2.5 font-display text-sm font-extrabold text-white hover:bg-forest"
          >
            View public cases
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="font-display text-3xl font-black text-forest-dark">Report a missing person</h1>
      <p className="mt-2 text-sm text-ink/70">
        Fields marked * are required. If the person is in immediate danger, call the Police on{" "}
        <strong>112</strong> before filling this form.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-6">
        <fieldset className="space-y-4 rounded-2xl border border-forest-mist bg-white p-5">
          <legend className="px-2 font-display text-sm font-extrabold uppercase tracking-widest text-forest">
            The missing person
          </legend>

          <div>
            <label className="label" htmlFor="fullName">Full name *</label>
            <input id="fullName" name="fullName" required maxLength={80} className="input" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="age">Age *</label>
              <input id="age" name="age" type="number" min={1} max={120} required className="input" />
            </div>
            <div>
              <label className="label" htmlFor="gender">Gender *</label>
              <select id="gender" name="gender" required className="input">
                <option value="">Select…</option>
                <option>Male</option>
                <option>Female</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="state">State last seen *</label>
              <select id="state" name="state" required className="input">
                <option value="">Select…</option>
                {NIGERIAN_STATES.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="lga">LGA / Area</label>
              <input id="lga" name="lga" maxLength={60} className="input" placeholder="e.g. Aba South" />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="lastSeenLocation">Last seen location *</label>
            <input
              id="lastSeenLocation"
              name="lastSeenLocation"
              required
              maxLength={120}
              className="input"
              placeholder="e.g. Ariaria Market gate, Faulks Road"
            />
          </div>

          <div>
            <label className="label" htmlFor="lastSeenDate">Last seen date *</label>
            <input id="lastSeenDate" name="lastSeenDate" type="date" required className="input" />
          </div>

          <div>
            <label className="label" htmlFor="description">
              Description &amp; circumstances *
            </label>
            <textarea
              id="description"
              name="description"
              required
              rows={4}
              maxLength={2000}
              className="input"
              placeholder="Height, complexion, what they were wearing, and what happened…"
            />
          </div>

          <div>
            <label className="label" htmlFor="photo">Photo (JPG/PNG/WebP, max 5 MB)</label>
            <input
              id="photo"
              name="photo"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="input"
              onChange={(e) => {
                const f = e.target.files?.[0];
                setPreview(f ? URL.createObjectURL(f) : null);
              }}
            />
            {preview && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="Preview" className="mt-2 h-32 rounded-lg object-cover" />
            )}
          </div>
        </fieldset>

        <fieldset className="space-y-4 rounded-2xl border border-forest-mist bg-white p-5">
          <legend className="px-2 font-display text-sm font-extrabold uppercase tracking-widest text-forest">
            Your details
          </legend>

          <div>
            <label className="label" htmlFor="reporterName">Your full name *</label>
            <input id="reporterName" name="reporterName" required maxLength={80} className="input" />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="reporterPhone">Your phone (private) *</label>
              <input
                id="reporterPhone"
                name="reporterPhone"
                type="tel"
                required
                className="input"
                placeholder="0803 123 4567"
              />
              <p className="mt-1 text-xs text-ink/50">Only our review team sees this.</p>
            </div>
            <div>
              <label className="label" htmlFor="contactPhone">Public contact phone *</label>
              <input
                id="contactPhone"
                name="contactPhone"
                type="tel"
                required
                className="input"
                placeholder="0803 123 4567"
              />
              <p className="mt-1 text-xs text-ink/50">
                Shown on the case page so people can call with information.
              </p>
            </div>
          </div>

          <div>
            <label className="label" htmlFor="relationship">Relationship to the person *</label>
            <input
              id="relationship"
              name="relationship"
              required
              maxLength={60}
              className="input"
              placeholder="e.g. Sister, Neighbour, Employer"
            />
          </div>

          <label className="flex items-start gap-2 text-sm text-ink/80">
            <input type="checkbox" name="consent" required className="mt-1" />
            <span>
              I confirm this report is truthful and I have the right to share this
              person&apos;s details and photo publicly. *
            </span>
          </label>
        </fieldset>

        {error && (
          <p className="rounded-lg bg-red-100 px-4 py-3 text-sm font-medium text-red-700">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-forest-dark py-3.5 font-display text-base font-extrabold text-white hover:bg-forest disabled:opacity-60"
        >
          {submitting ? "Submitting…" : "Submit report"}
        </button>
      </form>
    </div>
  );
}
