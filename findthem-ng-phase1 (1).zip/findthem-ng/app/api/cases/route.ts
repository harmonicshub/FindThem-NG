import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { readCases, writeCases, nextCaseNumber, publicCases } from "@/lib/db";
import { MissingCase } from "@/lib/types";
import { NIGERIAN_STATES } from "@/lib/states";

export const dynamic = "force-dynamic";

const PHONE_RE = /^(\+?234|0)[789][01]\d{8}$/;
const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
const PHOTO_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export async function GET(req: NextRequest) {
  const cases = publicCases(await readCases());
  const q = req.nextUrl.searchParams.get("q")?.trim().toLowerCase() || "";
  const filtered = q
    ? cases.filter((c) =>
        `${c.fullName} ${c.lastSeenLocation} ${c.lga} ${c.state}`.toLowerCase().includes(q)
      )
    : cases;
  // Never expose the reporter's private details on the public endpoint
  const safe = filtered.map(({ reporterName, reporterPhone, ...rest }) => rest);
  return NextResponse.json(safe);
}

export async function POST(req: NextRequest) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Invalid form submission." }, { status: 400 });
  }

  const str = (k: string) => String(form.get(k) ?? "").trim();

  const fullName = str("fullName");
  const age = Number(str("age"));
  const gender = str("gender");
  const state = str("state");
  const lga = str("lga");
  const lastSeenLocation = str("lastSeenLocation");
  const lastSeenDate = str("lastSeenDate");
  const description = str("description");
  const reporterName = str("reporterName");
  const reporterPhone = str("reporterPhone").replace(/[\s-]/g, "");
  const contactPhone = str("contactPhone").replace(/[\s-]/g, "");
  const relationship = str("relationship");
  const consent = form.get("consent");

  if (!fullName || fullName.length > 80)
    return NextResponse.json({ error: "Please enter the person's full name." }, { status: 400 });
  if (!Number.isInteger(age) || age < 1 || age > 120)
    return NextResponse.json({ error: "Please enter a valid age (1–120)." }, { status: 400 });
  if (gender !== "Male" && gender !== "Female")
    return NextResponse.json({ error: "Please select a gender." }, { status: 400 });
  if (!NIGERIAN_STATES.includes(state))
    return NextResponse.json({ error: "Please select a valid state." }, { status: 400 });
  if (!lastSeenLocation || lastSeenLocation.length > 120)
    return NextResponse.json({ error: "Please enter the last seen location." }, { status: 400 });
  if (!lastSeenDate || isNaN(new Date(lastSeenDate).getTime()))
    return NextResponse.json({ error: "Please enter a valid last seen date." }, { status: 400 });
  if (new Date(lastSeenDate) > new Date())
    return NextResponse.json({ error: "Last seen date cannot be in the future." }, { status: 400 });
  if (!description || description.length > 2000)
    return NextResponse.json({ error: "Please add a description (max 2000 characters)." }, { status: 400 });
  if (!reporterName || reporterName.length > 80)
    return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (!PHONE_RE.test(reporterPhone))
    return NextResponse.json(
      { error: "Please enter a valid Nigerian phone number for yourself (e.g. 08031234567)." },
      { status: 400 }
    );
  if (!PHONE_RE.test(contactPhone))
    return NextResponse.json(
      { error: "Please enter a valid Nigerian public contact number (e.g. 08031234567)." },
      { status: 400 }
    );
  if (!relationship || relationship.length > 60)
    return NextResponse.json({ error: "Please state your relationship to the person." }, { status: 400 });
  if (!consent)
    return NextResponse.json({ error: "Please tick the consent box to submit." }, { status: 400 });

  // Optional photo
  let photoUrl: string | null = null;
  const photo = form.get("photo");
  if (photo instanceof File && photo.size > 0) {
    const ext = PHOTO_TYPES[photo.type];
    if (!ext)
      return NextResponse.json(
        { error: "Photo must be a JPG, PNG or WebP image." },
        { status: 400 }
      );
    if (photo.size > MAX_PHOTO_BYTES)
      return NextResponse.json({ error: "Photo must be 5 MB or smaller." }, { status: 400 });

    const filename = `${randomUUID()}.${ext}`;
    const uploadDir = path.join(process.cwd(), "public", "uploads");
    await fs.mkdir(uploadDir, { recursive: true });
    await fs.writeFile(path.join(uploadDir, filename), Buffer.from(await photo.arrayBuffer()));
    photoUrl = `/uploads/${filename}`;
  }

  const cases = await readCases();
  const now = new Date().toISOString();
  const newCase: MissingCase = {
    id: randomUUID(),
    caseNumber: nextCaseNumber(cases),
    fullName,
    age,
    gender: gender as "Male" | "Female",
    state,
    lga,
    lastSeenLocation,
    lastSeenDate,
    description,
    photoUrl,
    contactPhone,
    reporterName,
    reporterPhone,
    relationship,
    status: "pending",
    createdAt: now,
    updatedAt: now,
  };

  cases.push(newCase);
  await writeCases(cases);

  return NextResponse.json({ ok: true, caseNumber: newCase.caseNumber }, { status: 201 });
}
