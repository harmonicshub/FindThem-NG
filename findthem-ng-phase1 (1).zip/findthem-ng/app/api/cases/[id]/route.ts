import { NextResponse } from "next/server";
import { readCases } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const cases = await readCases();
  const c = cases.find(
    (x) => x.id === params.id && (x.status === "missing" || x.status === "found")
  );
  if (!c) return NextResponse.json({ error: "Case not found." }, { status: 404 });
  const { reporterName, reporterPhone, ...safe } = c;
  return NextResponse.json(safe);
}
