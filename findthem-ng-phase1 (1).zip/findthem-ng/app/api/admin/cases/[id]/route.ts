import { NextRequest, NextResponse } from "next/server";
import { readCases, writeCases } from "@/lib/db";
import { CaseStatus } from "@/lib/types";

const VALID: CaseStatus[] = ["pending", "missing", "found", "rejected"];

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { status } = await req.json().catch(() => ({ status: "" }));
  if (!VALID.includes(status)) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }
  const cases = await readCases();
  const c = cases.find((x) => x.id === params.id);
  if (!c) return NextResponse.json({ error: "Case not found." }, { status: 404 });

  c.status = status;
  c.updatedAt = new Date().toISOString();
  await writeCases(cases);
  return NextResponse.json(c);
}
