import { NextResponse } from "next/server";
import { readCases } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const cases = await readCases();
  const order = { pending: 0, missing: 1, found: 2, rejected: 3 } as const;
  cases.sort((a, b) => order[a.status] - order[b.status] || (a.createdAt < b.createdAt ? 1 : -1));
  return NextResponse.json(cases);
}
