"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CaseStatus, MissingCase } from "@/lib/types";
import { formatDate } from "@/lib/format";
import StatusBadge from "@/components/StatusBadge";

const TABS: { key: CaseStatus; label: string }[] = [
  { key: "pending", label: "Pending" },
  { key: "missing", label: "Active" },
  { key: "found", label: "Found" },
  { key: "rejected", label: "Rejected" },
];

export default function AdminPage() {
  const router = useRouter();
  const [cases, setCases] = useState<MissingCase[] | null>(null);
  const [tab, setTab] = useState<CaseStatus>("pending");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await fetch("/api/admin/cases");
    if (res.status === 401) {
      router.push("/admin/login");
      return;
    }
    if (!res.ok) {
      setError("Could not load cases. Refresh to try again.");
      return;
    }
    setCases(await res.json());
  }, [router]);

  useEffect(() => {
    load();
  }, [load]);

  async function setStatus(id: string, status: CaseStatus) {
    setBusyId(id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/cases/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error();
      await load();
    } catch {
      setError("Update failed. Check your connection and try again.");
    } finally {
      setBusyId(null);
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
  }

  const shown = (cases ?? []).filter((c) => c.status === tab);
  const counts = TABS.map((t) => (cases ?? []).filter((c) => c.status === t.key).length);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-black text-forest-dark">Review dashboard</h1>
        <button onClick={logout} className="text-sm font-semibold text-ink/60 hover:text-forest-dark">
          Sign out
        </button>
      </div>

      <div className="mt-5 flex gap-2 overflow-x-auto">
        {TABS.map((t, i) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`shrink-0 rounded-full px-4 py-2 font-display text-sm font-extrabold ${
              tab === t.key
                ? "bg-forest-dark text-white"
                : "bg-white text-ink/70 ring-1 ring-forest-mist hover:text-forest-dark"
            }`}
          >
            {t.label} ({counts[i]})
          </button>
        ))}
      </div>

      {error && (
        <p className="mt-4 rounded-lg bg-red-100 px-4 py-3 text-sm font-medium text-red-700">{error}</p>
      )}

      {cases === null ? (
        <p className="mt-8 text-sm text-ink/60">Loading cases…</p>
      ) : shown.length === 0 ? (
        <p className="mt-8 rounded-xl border border-dashed border-forest-mist bg-white p-8 text-center text-sm text-ink/60">
          Nothing in this list.
        </p>
      ) : (
        <div className="mt-5 space-y-4">
          {shown.map((c) => (
            <div key={c.id} className="rounded-xl border border-forest-mist bg-white p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex gap-4">
                  {c.photoUrl && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={c.photoUrl}
                      alt=""
                      className="h-20 w-20 shrink-0 rounded-lg object-cover"
                    />
                  )}
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusBadge status={c.status} />
                      <span className="text-xs font-semibold text-ink/50">{c.caseNumber}</span>
                    </div>
                    <h2 className="mt-1 font-display text-xl font-extrabold text-forest-dark">
                      {c.fullName}, {c.age} · {c.gender}
                    </h2>
                    <p className="text-sm text-ink/70">
                      Last seen {c.lastSeenLocation}
                      {c.lga ? `, ${c.lga}` : ""}, {c.state} — {formatDate(c.lastSeenDate)}
                    </p>
                    <p className="mt-2 max-w-xl whitespace-pre-line text-sm text-ink/80">
                      {c.description}
                    </p>
                    <p className="mt-2 text-xs text-ink/50">
                      Reporter: {c.reporterName} ({c.relationship}) · {c.reporterPhone} · Public
                      contact: {c.contactPhone} · Submitted {formatDate(c.createdAt)}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {c.status === "pending" && (
                    <>
                      <button
                        disabled={busyId === c.id}
                        onClick={() => setStatus(c.id, "missing")}
                        className="rounded-lg bg-forest-dark px-4 py-2 font-display text-sm font-extrabold text-white hover:bg-forest disabled:opacity-60"
                      >
                        Approve
                      </button>
                      <button
                        disabled={busyId === c.id}
                        onClick={() => setStatus(c.id, "rejected")}
                        className="rounded-lg bg-red-600 px-4 py-2 font-display text-sm font-extrabold text-white hover:bg-red-700 disabled:opacity-60"
                      >
                        Reject
                      </button>
                    </>
                  )}
                  {c.status === "missing" && (
                    <button
                      disabled={busyId === c.id}
                      onClick={() => setStatus(c.id, "found")}
                      className="rounded-lg bg-found px-4 py-2 font-display text-sm font-extrabold text-white hover:opacity-90 disabled:opacity-60"
                    >
                      Mark as found
                    </button>
                  )}
                  {(c.status === "found" || c.status === "rejected") && (
                    <button
                      disabled={busyId === c.id}
                      onClick={() => setStatus(c.id, "missing")}
                      className="rounded-lg bg-white px-4 py-2 font-display text-sm font-extrabold text-forest-dark ring-1 ring-forest-mist hover:bg-forest-mist disabled:opacity-60"
                    >
                      Reopen as missing
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
