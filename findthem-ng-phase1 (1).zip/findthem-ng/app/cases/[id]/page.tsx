import { notFound } from "next/navigation";
import { readCases } from "@/lib/db";
import { formatDate, initials } from "@/lib/format";
import StatusBadge from "@/components/StatusBadge";

export const dynamic = "force-dynamic";

export default async function CaseDetailPage({ params }: { params: { id: string } }) {
  const all = await readCases();
  const c = all.find(
    (x) => x.id === params.id && (x.status === "missing" || x.status === "found")
  );
  if (!c) notFound();

  const shareText = encodeURIComponent(
    `🔍 MISSING PERSON — ${c.fullName}, ${c.age}\n` +
      `Last seen: ${c.lastSeenLocation}, ${c.state} on ${formatDate(c.lastSeenDate)}.\n` +
      `If you have any information, call ${c.contactPhone}.\n` +
      `Case ${c.caseNumber} on FindThem NG.`
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="overflow-hidden rounded-2xl border border-forest-mist bg-white shadow-sm">
        <div className="relative h-72 bg-forest-dark sm:h-80">
          {c.photoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={c.photoUrl}
              alt={`Photo of ${c.fullName}`}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="grid h-full w-full place-items-center font-display text-7xl font-black text-white/30">
              {initials(c.fullName)}
            </div>
          )}
          <div className="absolute left-0 top-4 flex items-center gap-2">
            <StatusBadge status={c.status} />
            <span className="rounded-r bg-black/50 px-2 py-0.5 text-xs font-semibold text-white">
              {c.caseNumber}
            </span>
          </div>
        </div>

        <div className="space-y-5 p-5 sm:p-7">
          <div>
            <h1 className="font-display text-3xl font-black text-forest-dark">
              {c.fullName}, {c.age}
            </h1>
            <p className="mt-1 text-sm text-ink/60">
              {c.gender} · Reported {formatDate(c.createdAt)}
            </p>
          </div>

          <dl className="grid gap-4 rounded-xl bg-forest-mist/50 p-4 sm:grid-cols-2">
            <div>
              <dt className="label">Last seen location</dt>
              <dd className="text-sm font-medium">
                {c.lastSeenLocation}
                {c.lga ? `, ${c.lga}` : ""}, {c.state}
              </dd>
            </div>
            <div>
              <dt className="label">Last seen date</dt>
              <dd className="text-sm font-medium">{formatDate(c.lastSeenDate)}</dd>
            </div>
          </dl>

          <div>
            <h2 className="label">Description &amp; circumstances</h2>
            <p className="whitespace-pre-line text-sm leading-relaxed text-ink/80">
              {c.description}
            </p>
          </div>

          {c.status === "missing" ? (
            <div className="rounded-xl border-2 border-alert/30 bg-alert-bg p-4">
              <h2 className="font-display text-lg font-extrabold text-alert">
                Have you seen {c.fullName.split(" ")[0]}?
              </h2>
              <p className="mt-1 text-sm text-ink/80">
                Call <a href={`tel:${c.contactPhone}`} className="font-bold underline">{c.contactPhone}</a>{" "}
                with any information — even small details help. If the person is in immediate
                danger, call the Police on <strong>112</strong>.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a
                  href={`https://wa.me/?text=${shareText}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg bg-[#25D366] px-4 py-2.5 font-display text-sm font-extrabold text-white hover:opacity-90"
                >
                  Share on WhatsApp
                </a>
                <a
                  href={`tel:${c.contactPhone}`}
                  className="rounded-lg bg-forest-dark px-4 py-2.5 font-display text-sm font-extrabold text-white hover:bg-forest"
                >
                  Call now
                </a>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border-2 border-found/30 bg-found-bg p-4">
              <h2 className="font-display text-lg font-extrabold text-found">
                Good news — this person has been found.
              </h2>
              <p className="mt-1 text-sm text-ink/80">
                This case is kept visible so shared links stay accurate.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
