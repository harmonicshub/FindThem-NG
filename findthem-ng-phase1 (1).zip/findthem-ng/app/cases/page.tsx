import { readCases, publicCases } from "@/lib/db";
import { NIGERIAN_STATES } from "@/lib/states";
import CaseCard from "@/components/CaseCard";

export const dynamic = "force-dynamic";

interface Props {
  searchParams: { q?: string; state?: string; status?: string; gender?: string };
}

export default async function CasesPage({ searchParams }: Props) {
  const { q = "", state = "", status = "", gender = "" } = searchParams;
  const all = publicCases(await readCases());

  const query = q.trim().toLowerCase();
  const cases = all.filter((c) => {
    if (query) {
      const hay = `${c.fullName} ${c.lastSeenLocation} ${c.lga} ${c.state}`.toLowerCase();
      if (!hay.includes(query)) return false;
    }
    if (state && c.state !== state) return false;
    if (status && c.status !== status) return false;
    if (gender && c.gender !== gender) return false;
    return true;
  });

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="font-display text-3xl font-black text-forest-dark">All cases</h1>

      <form
        method="GET"
        className="mt-5 grid grid-cols-2 gap-2 rounded-xl border border-forest-mist bg-white p-3 sm:grid-cols-5"
      >
        <input
          type="search"
          name="q"
          defaultValue={q}
          placeholder="Name or location…"
          className="input col-span-2 sm:col-span-2"
        />
        <select name="state" defaultValue={state} className="input">
          <option value="">All states</option>
          {NIGERIAN_STATES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select name="status" defaultValue={status} className="input">
          <option value="">All statuses</option>
          <option value="missing">Missing</option>
          <option value="found">Found</option>
        </select>
        <div className="col-span-2 flex gap-2 sm:col-span-1">
          <select name="gender" defaultValue={gender} className="input">
            <option value="">Any gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
          <button
            type="submit"
            className="shrink-0 rounded-lg bg-forest-dark px-4 font-display text-sm font-extrabold text-white hover:bg-forest"
          >
            Filter
          </button>
        </div>
      </form>

      <p className="mt-4 text-sm text-ink/60">
        {cases.length} case{cases.length === 1 ? "" : "s"} found
      </p>

      {cases.length === 0 ? (
        <div className="mt-4 rounded-xl border border-dashed border-forest-mist bg-white p-10 text-center text-sm text-ink/60">
          No cases match these filters. Try clearing the search or choosing a different state.
        </div>
      ) : (
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {cases.map((c) => (
            <CaseCard key={c.id} c={c} />
          ))}
        </div>
      )}
    </div>
  );
}
